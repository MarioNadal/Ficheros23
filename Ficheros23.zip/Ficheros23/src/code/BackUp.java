package code;

import java.nio.file.Files;
import java.nio.file.Path;

public class BackUp {
    public static void backUpDirectory() {
        Path p1 = Path.of("src/resources/dirBackup");
    }
}
